# Growtopia enet proxy (added more features)
## OpenSSL Download https://slproweb.com/download/Win64OpenSSL-3_0_5.exe

## Features
* /proxy (Shows proxy commands)
* /dropwl [amount]
* /dropdl [amount]
* /dropbgl [amount]
* /wrenchset [pull/kick/ban] (Change wrench mode)
* /wm (Enable/Disable Wrench Mode)
* /tp [name] (Teleport To Target Player)
* /ghost (Ghost Mode)
* /uid [name] (Resolve Target UID)
* /warp [world] (Warp To Other World)
* /flag [id] (Change Flag To Item ID)
* /skin [id] (Change Skin To Skin ID)
* /country [key] (Change Flag To Other Country)
* /name [name] (Change GrowID But Its Visual)
* /fd (Enable/Disable Fast Drop)
* /ft (Enable/Disable Fast Trash)
* /pullall (Pull All Player In Same World)
* /banall (Ban All Player In Same World)
* /tradeall (Trade All Player In Same World)

# By Joakim(https://github.com/JoakimTheCoder)


